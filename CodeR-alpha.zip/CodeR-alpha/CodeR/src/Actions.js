const ACTIONS = {
    JOIN : 'join',
    JOINED : 'joined',
    DISCONNECTED : 'disconnected',
    CODE_CHANGED : 'code_changed',
    SYNC_CODE: 'sync_code',
    LEAVE: 'leave',
};

module.exports = ACTIONS;